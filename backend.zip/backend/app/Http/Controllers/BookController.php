<?php 
namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BookController extends Controller
{
    // sort, search and pagination of a single book
    public function index(Request $request)
    {
        $query = Book::query();

        // Sort books by title
        if ($request->has('sort_by')) {
                $query->sortBy('title'); 
        }

        // Search books by title or author or genre
        if ($request->has('search')) {
            $searchTerm = $request->input('search');
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'like', "%{$searchTerm}%")
                  ->orWhere('author', 'like', "%{$searchTerm}%")
                  ->orWhere('genre', 'like', "%{$searchTerm}%");
            });
        }

        // Paginate books per page as 10 element in one page
        $perPage = $request->input('per_page', 10);
        $books = $query->paginate($perPage);

        return response()->json($books);
    }
    // create record of a singe book
    public function store(Request $request)
    {

        $book = Book::create([
            'title' => $request->input('title'),
            'author' => $request->input('author'),
            'genre' => $request->input('genre'),
            'published_year' => $request->input('published_year'),
        ]);

        return response()->json($book, 200);
    }

    // show record of a single book
    public function show($request)
    {
        $searchTerm = $request->input('title');

        $book = Book::where('title', 'ilike', '%' . $searchTerm . '%')->first();

        if ($book) {
            return response()->json($book,200);
        } else {
            return response()->json(['message' => 'Book not found.'], 404);
        }
    }
    // update values of book by tittle
    public function update(Request $request, $id)
    {
        $title = $request->input('title');

        $book = Book::where('title', $title)->first();

        if ($book) {
            $book->update($request->only(['author', 'genre', 'published_year']));

            return response()->json($book,200);
        } else {
            return response()->json(['message' => 'Book not found.'], 404);
        }
    }
    // delete a single book by titile
    public function delete(Request $request)
    {
        $title = $request->input('title');

        $book = Book::where('title', $title)->first();

        if ($book) {
            $book->delete();
            return response()->json(['message' => 'Book deleted successfully.'],200);
        } else {
            return response()->json(['message' => 'Book not found.'], 404);
        }
    }
    // show all book sort by ascending
    public function showAllBooks()
    {
        $books = Book::orderBy('title', 'asc')->get();

        return response()->json($books);
    }
}
