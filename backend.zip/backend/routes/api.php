<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/books/book_list', [BookController::class, 'index']);
Route::post('/books/create', [BookController::class, 'store']);
//for viewing single book
Route::post('/books/find', [BookController::class, 'show']);
Route::post('/books/update', [BookController::class, 'update']);
Route::post('/books/delete', [BookController::class, 'delete']);
//for viewing all books
Route::get('/books/all_books', [BookController::class, 'showAllBooks']);
